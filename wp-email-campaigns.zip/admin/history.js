(function ($) {
  // Currently all server-side. Keep for future (inline actions/filtering).
})(jQuery);
