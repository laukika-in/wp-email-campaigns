=== WP Email Campaigns ===
Contributors: anirudh
Requires at least: 6.2
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Transactional email campaigns via CPT with Excel/CSV import, Action Scheduler based sending (1 email/3s), contacts, and reporting. Integrates with WP Mail SMTP.
